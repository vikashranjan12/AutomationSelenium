

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownRediff {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("http://register.rediff.com/register/register.php?FormName=user_details");
	    Thread.sleep(2000);
	    Driver1.findElement(By.xpath("//*[contains(@name,'name')]")).sendKeys("sfkfs");
	    Thread.sleep(2000);
	    Driver1.findElement(By.xpath("(//*[@type='text'])[2]")).sendKeys("sfkfs");
	    Thread.sleep(2000);
	    Driver1.findElement(By.xpath("(//*[@type='password'])[1]")).sendKeys("sfkfs");
	    Driver1.findElement(By.xpath("(//*[@type='password'])[2]")).sendKeys("sfkfs");
	    Thread.sleep(2000);
	    Driver1.findElement(By.xpath("(//*[@type='checkbox'])[1]")).click();
	    
	    Driver1.findElement(By.xpath("//*[@src='http://register.rediff.com/utilities/newforgot/img/darrow_country.png']")).click();
	    Driver1.findElement(By.xpath("//*[text()='USA / Canada (+1)']")).click();
	    Thread.sleep(2000);
	    
	    Driver1.findElement(By.xpath("//*[@type='radio' and @value='m' ]")).click();
	    
	 
	    Select s=new Select(Driver1.findElement(By.id("country")));
	    s.selectByIndex(219);
	    Thread.sleep(2000);
	    
	    Driver1.close();
	}

}