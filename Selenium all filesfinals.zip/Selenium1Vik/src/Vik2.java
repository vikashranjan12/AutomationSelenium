import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

public class Vik2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","D:\\seleniumjarfiles\\geckodriver.exe");
		WebDriver Driver1=new FirefoxDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://www.google.com/");
		Driver1.close();
		

	}

}
