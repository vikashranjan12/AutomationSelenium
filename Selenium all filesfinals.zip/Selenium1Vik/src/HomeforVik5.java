import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

public class HomeforVik5 {
	public static WebDriver Driver1;
	public static String value,url;
	   
	public static void func0() {
    	System.out.println("enter your browser");
		Scanner sc=new Scanner(System.in);
		value=sc.nextLine();
		System.out.println("enter your url");
		url=sc.nextLine();
    }
	
	
	   public static String URLS() throws IOException {
		    Driver1.get(url);
		    String currenturl= Driver1.getCurrentUrl();
			Driver1.manage().window().maximize();
			System.out.println(currenturl);
			
			if(url.equals(currenturl))
			{
				//System.out.println("Test case is pass");
			 return("URLS is pass");
			}
			else
			{
				//System.out.println("Test case is fail");
			File scrFile=(File) ((TakesScreenshot)Driver1).getScreenshotAs(OutputType.FILE);
			Files.copy(scrFile, new File("D:\\seleniumjarfiles\\first.jpg"));
			return("URL is fail");
			}
			
		  }
		    public static String Bcall() {
				
				   if(value.equals("firefox")) {
						System.setProperty("webdriver.gecko.driver","D:\\seleniumjarfiles\\geckodriver.exe");
						Driver1 = new FirefoxDriver();
					    return ("Bcall is pass");
						}
				   else if(value.equals("chrome")) {
							
							System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
							Driver1=new ChromeDriver();
							return ("Bcall is pass");
							
						}
						else 
						{
							System.out.println("invalid choice");
							return ("Bcall is fail");
						}
		    }
		    public static String Appcl()
		    { 
		    	String x="Appclose is fail";
		    	Driver1.close();
		    	x="Appclose is pass";
		    	return x;
		    	
		    }
				

}
