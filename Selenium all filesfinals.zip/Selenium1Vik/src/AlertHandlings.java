import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertHandlings{
	  
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		
		 
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("http://demo.automationtesting.in/Alerts.html");
		Driver1.findElement(By.xpath("//*[@id=\"OKTab\"]/button")).click();
		Driver1.switchTo().alert().accept();
		Driver1.close();
		
	}
	
}