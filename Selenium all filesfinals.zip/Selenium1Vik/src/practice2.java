import org.openqa.selenium.By;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class practice2 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://www.softwarecertifications.org/");
	    Thread.sleep(2000);
	    Driver1.findElement(By.xpath("//nav[@id='site-nav']/ul/li[4]/a")).click();
	    Thread.sleep(2000);
	    
	}
}
