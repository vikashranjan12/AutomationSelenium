import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DEMOOO1 
{
	public static void main(String a[]) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F%3Ftab%3Drm%26ogbl&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
	    Thread.sleep(2000);
	    //System.out.println(Driver1.getTitle());
	    Driver1.findElement(By.linkText("Help")).click();
	    
	    Set <String> id=Driver1.getWindowHandles();
	    Iterator<String> it=id.iterator();
	    String vParent=it.next();
	    String vChild=it.next();
	    
	    Driver1.switchTo().window(vChild); 

	    Driver1.findElement(By.linkText("Google Account")).click();
	    Thread.sleep(2000);
	    Set <String> id2=Driver1.getWindowHandles();
	    Iterator<String> it2=id2.iterator();
	    
	    while(it2.hasNext())
	    {
	    	if(!it2.equals(vParent))
	    	{
	    		
	    	}
	    }
	    
	    
	}
}
