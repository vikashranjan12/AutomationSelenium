import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Vik3 {

	       
	    

	public static void main(String[] args) {
		String value;
		System.out.println("enter your browser");
		Scanner sc=new Scanner(System.in);
			value=sc.nextLine();
				
		
		if(value.equals("firefox")) {
		System.setProperty("webdriver.gecko.driver","D:\\seleniumjarfiles\\geckodriver.exe");
		WebDriver Driver1=new FirefoxDriver();
	    Driver1.manage().window().maximize();
	    Driver1.get("https://www.google.com/");
		    Driver1.close();
		
	
		}
		if(value.equals("chrome")) {
			
			System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
			     WebDriver Driver1=new ChromeDriver();
			    Driver1.manage().window().maximize();
			    Driver1.get("https://www.google.com/");
			    Driver1.close();
			
		}
		else 
		{
			System.out.println("invalid choice");
		}

	}
}
