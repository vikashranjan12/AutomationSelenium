import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Vik4 {
	public static WebDriver Driver1;

	public static void main(String[] args) {
		String value;
		System.out.println("enter your browser");
		Scanner sc=new Scanner(System.in);
		value=sc.nextLine();
				
		
		if(value.equals("firefox")) {
		System.setProperty("webdriver.gecko.driver","D:\\seleniumjarfiles\\geckodriver.exe");
		Driver1 = new FirefoxDriver();
		func2();
	
		}
		if(value.equals("chrome")) {
			
			System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
			Driver1=new ChromeDriver();
			func2();
			
		}
		else 
		{
			System.out.println("invalid choice");
		}
		
		

	}
	    public static void func2() {
		Driver1.manage().window().maximize();
		Driver1.get("https://www.google.com/");
	    Driver1.close();
		}
}
