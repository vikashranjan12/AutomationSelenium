import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ProjectSelnm {

	  static int fd[]= {100,200,300};
	  static int clt[]= {10,20,30};
	  static int sht[]= {50,75,100};
	  static int mpay[]= {500,100,400};
	  static int mothers[]= {50,20,10};
	  
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		
		 
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("http://www.youcandealwithit.com/");
		Thread.sleep(2000);
		Actions act=new Actions(Driver1);
        act.moveToElement(Driver1.findElement(By.xpath("//*[@id='siteNav']/li/a"))).build().perform();
        Thread.sleep(2000);
        Driver1.findElement(By.linkText("Calculators & Resources")).click();
	    Thread.sleep(1000);
	    Driver1.findElement(By.linkText("Calculators")).click();
	    Thread.sleep(1000);
	    Driver1.findElement(By.linkText("Budget Calculator")).click();
	    Thread.sleep(1000);
	    for(int i=0;i<3;i++) {
	    Driver1.findElement(By.id("food")).sendKeys(""+fd[i]);
	    Thread.sleep(1000);
	    Driver1.findElement(By.id("clothing")).sendKeys(""+clt[i]);
	    Thread.sleep(1000);
	    Driver1.findElement(By.id("shelter")).sendKeys(""+sht[i]);
	    Thread.sleep(1000);
	    Driver1.findElement(By.id("monthlyPay")).sendKeys(""+mpay[i]);
	    Thread.sleep(1000);
	    Driver1.findElement(By.id("monthlyOther")).sendKeys(""+mothers[i]);
	    Thread.sleep(3000);
	    String a=Driver1.findElement(By.id("totalMonthlyIncome")).getAttribute("value");
	    Thread.sleep(1000);
	    System.out.println(a);
	    String b=Driver1.findElement(By.id("totalMonthlyExpenses")).getAttribute("value");
	    Thread.sleep(1000);
	    System.out.println(b);
	    String c=Driver1.findElement(By.id("underOverBudget")).getAttribute("value");
		      
	        float Income=Float.parseFloat(a);
	        float Expense=Float.parseFloat(b);
	        if(Income>Expense) {
	        	System.out.println("warren Buffer");
	        }
	        else{
	        	System.out.println("you are poor at saving");
	        }
	    
	    Thread.sleep(3000);
	    
//	    Driver1.findElement(By.id("food")).clear();
//	    Thread.sleep(1000);
//	    Driver1.findElement(By.id("clothing")).clear();
//	    Thread.sleep(1000);
//	    Driver1.findElement(By.id("shelter")).clear();
//	    Thread.sleep(1000);
//	    Driver1.findElement(By.id("monthlyPay")).clear();
//	    Thread.sleep(1000);
//	    Driver1.findElement(By.id("monthlyOther")).clear();
//	    Thread.sleep(3000);
	    
	    Driver1.findElement(By.className("reset")).click();
	    Thread.sleep(2000);
	    }
	    Thread.sleep(3000);
	    Driver1.close();
	}
}