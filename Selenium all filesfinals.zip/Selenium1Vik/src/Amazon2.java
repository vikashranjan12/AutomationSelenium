

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Amazon2 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://www.amazon.com/");
		Driver1.findElement(By.id("twotabsearchtextbox")).sendKeys("Fossil watch for men");
		Driver1.findElement(By.id("twotabsearchtextbox")).sendKeys(Keys.ENTER);
		//Driver1.findElement(By.className("nav-input")).click();
		Thread.sleep(3000);
		System.out.println(Driver1.getTitle());
		Driver1.findElement(By.xpath("//*[text()='Fossil']")).click();
		Thread.sleep(2000);
		Driver1.findElement(By.xpath("//*[contains(text(),'Gen 5')]")).click();
        Thread.sleep(2000);
        
        Actions act=new Actions(Driver1);
        act.moveToElement(Driver1.findElement(By.id("nav-link-accountList"))).build().perform();
        //Driver1.findElement(By.xpath("//*[contains(text(),'Gen 5')]")).click();
        Thread.sleep(2000);
        Driver1.findElement(By.xpath("//*[@id='nav-flyout-ya-signin']/a/span")).click();
		Thread.sleep(5000);
        Driver1.close();


	}

}
