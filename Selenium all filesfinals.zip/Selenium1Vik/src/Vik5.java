import java.io.IOException;
import java.util.Scanner;


public class Vik5 {

public static void main(String[] args) throws IOException 
	{
		HomeforVik5 xy=new HomeforVik5();
		xy.func0();
		System.out.println(xy.Bcall());
		System.out.println(xy.URLS());
		System.out.println(xy.Appcl());
		
	}
}
	
	
	
	
	
	
	
	

