import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://www.facebook.com/");
		Driver1.findElement(By.id("email")).sendKeys("vikashdummy@gmail.com");
		Thread.sleep(3000);
		Driver1.findElement(By.id("pass")).sendKeys("fskfjsfjs");
		Thread.sleep(3000);
		Driver1.findElement(By.linkText("Forgotten account?")).click();
		Thread.sleep(3000);
		Driver1.close();
	}

}
