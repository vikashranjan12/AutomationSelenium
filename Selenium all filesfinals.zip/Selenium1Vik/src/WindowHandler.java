
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class WindowHandler {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F%3Ftab%3Drm%26ogbl&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
	    Thread.sleep(2000);
	    myprint(Driver1.getTitle());
	    
	    
	    Driver1.findElement(By.linkText("Help")).click();
	    Thread.sleep(2000);
	    
	    

	    Set <String> id=Driver1.getWindowHandles();
	    Iterator<String> it=id.iterator();
	    String vParent=it.next();
	    String vChild=it.next();
	    
	    
	   Driver1.switchTo().window(vChild);   //this line for switch to child window needed once 
	                                           //bcz every time this tab refreshes does not create new tab doesnt matter how many child
	    
	    
	    myprint(Driver1.getTitle());
	    
	    Driver1.findElement(By.linkText("Community")).click();
	    Thread.sleep(2000);
	    myprint(Driver1.getTitle());
	    
	    
	    Driver1.findElement(By.linkText("Google Account")).click();
	    Set <String> id2=Driver1.getWindowHandles();                 //for a parent and his children requires only one window handler like for gmail parent: help,privacy(and community like twins) and terms are children ,for next genration requires new handler like privacy to google account,google account is the child of privacy so requires handler2 similarly from google account to youtube that is new generation req handlers
	    Iterator<String> it2=id2.iterator();
	    String vParent2=it2.next();
	    String vChild2=it2.next();
	    String vChild3=it2.next();
	  
	   Driver1.switchTo().window(vChild3);
	    Thread.sleep(2000);
	   myprint(Driver1.getTitle());
	    
	   Thread.sleep(1000);
	    
	    Driver1.quit();
	    
	}
	
	public static void myprint(String s)
	{
		System.out.println(s);
	}
	
}