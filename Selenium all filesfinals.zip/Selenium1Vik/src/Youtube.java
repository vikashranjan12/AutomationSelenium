
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Youtube {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://www.youtube.com/");
	    Driver1.findElement(By.id("search")).sendKeys("jab harry met sejal song");
	    Thread.sleep(2000);
	    Driver1.findElement(By.id("search-icon-legacy")).click();
	    Thread.sleep(1000);
	    Driver1.findElement(By.xpath("//*[contains(text(),'SAFAR Lyrical')]")).click();
	    Thread.sleep(1000);
	    Driver1.close();
	}

}