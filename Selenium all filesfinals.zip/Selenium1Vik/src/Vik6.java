
import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Vik6 {
	public static WebDriver Driver1;
	public static String value,url;
	
	
	 public static String func2() {
		    Driver1.get(url);
		    String currenturl= Driver1.getCurrentUrl();
			Driver1.manage().window().maximize();
			Driver1.get("https://www.google.com/");
			System.out.println(currenturl);
			Driver1.close();
			if(url.equals(currenturl))
			{
				//System.out.println("Test case is pass");
			    return("pass");
			}
			else
			{
				//System.out.println("Test case is fail");
				return("fail");
				
			}
			
		   
			
		   }
		    public static void func3(String b) {
		    	System.out.println(b);
		    }
		    public static void func1(){
		    	
		    	if(value.equals("firefox")) {
		    		System.setProperty("webdriver.gecko.driver","D:\\seleniumjarfiles\\geckodriver.exe");
		    		Driver1 = new FirefoxDriver();
		    		//func2();
		    		String a= func2();
		    		func3(a);
		    	
		    		}
		    		if(value.equals("chrome")) {
		    			
		    			System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		    			Driver1=new ChromeDriver();
		    			//func2();
		    			String a= func2();
		    			func3(a);
		    			
		    		}
		    		else 
		    		{
		    			System.out.println("invalid choice");
		    		}
		    }
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		System.out.println("enter your browser");
		Scanner sc=new Scanner(System.in);
		value=sc.nextLine();
		System.out.println("enter your url");
		url=sc.nextLine();
		func1();
	}
	   
}


