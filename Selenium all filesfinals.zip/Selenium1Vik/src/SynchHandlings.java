import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SynchHandlings{
	  
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		
		 
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://accounts.google.com/signin/v2/identifier?hl=en&passive=true&continue=http%3A%2F%2Fsupport.google.com%2Fmail%2F%3Fhl%3Den&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
		WebDriverWait wait=new WebDriverWait(Driver1,20);
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Help")));
		Driver1.findElement(By.linkText("Help")).click();
		Driver1.close();
		
	}
	
}