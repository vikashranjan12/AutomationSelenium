import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class amazonSel {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://www.amazon.com/");
		Driver1.findElement(By.id("twotabsearchtextbox")).sendKeys("msi laptop");
		Driver1.findElement(By.className("nav-input")).click();
		Thread.sleep(3000);
		System.out.println(Driver1.getTitle());
		Driver1.findElement(By.linkText("MSI GF63 Thin 9RCX -615 15.6\" Gaming Laptop, Intel Core i5-9300H, NVIDIA GTX 1050Ti, 8GB, 512GB NVMe SSD, Win10")).click();
		Thread.sleep(3000);
		Driver1.findElement(By.xpath("/html/body/div[2]/div[1]/div[7]/div[5]/div[1]/div[2]/div/div/div/form/div/div/div/div/div[2]/div/div[10]/div[1]/span/span/span/input")).click();
		Thread.sleep(5000);
		Driver1.findElement(By.xpath("/html/body/div[2]/div[1]/div[7]/div[5]/div[1]/div[2]/div/div/div/form/div/div/div/div/div[2]/div/div[10]/div[1]/span/span/span/input")).click();
        Thread.sleep(3000);
        Driver1.findElement(By.id("breadcrumb-back-link")).click();
        Thread.sleep(2000);
		Driver1.close();
		

	}

}
