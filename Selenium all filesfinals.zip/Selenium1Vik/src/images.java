import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class images {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\seleniumjarfiles\\chromedriver.exe");
		WebDriver Driver1=new ChromeDriver();
		Driver1.manage().window().maximize();
		Driver1.get("https://www.google.com/");
	    Driver1.findElement(By.name("q")).sendKeys("testing");

	    Thread.sleep(2000);
	    
//		Driver1.findElement(By.name("btnK")).click();
//		String b=Driver1.findElement(By.name("q")).getAttribute("value");
//		Thread.sleep(2000);
//		
//		
//		Thread.sleep(2000);
//		if(a.equals(b))
//		{
//			System.out.println("valid result");
//		}
//		else
//		{
//			System.out.println("invalid result");
//		}
//		
//
//		String c=Driver1.findElement(By.id("resultStats")).getText();
//	    System.out.println("time taken"+c);
	    //Driver1.close();
	    Driver1.findElement(By.name("btnK")).click();
	    Driver1.findElement(By.id("hdtb-msb-vis")).click();
	    Thread.sleep(2000);
	    Driver1.findElement(By.partialLinkText("Software Testing Professionals ")).click();
	    Thread.sleep(2000);
	    Driver1.close();
	    
	}
}
